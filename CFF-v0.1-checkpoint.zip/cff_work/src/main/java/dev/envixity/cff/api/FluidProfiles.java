package dev.envixity.cff.api;

/** Default CFF profiles. Values are intentionally vanilla-like starting points. */
public final class FluidProfiles {
    private FluidProfiles() {}

    public static final FluidProfile WATER = new FluidProfile("water", FluidClass.WATER, 5, 1);
    public static final FluidProfile LAVA  = new FluidProfile("lava",  FluidClass.LAVA, 30, 2);
}
