# Finish/build CFF

## Easiest: GitHub Actions
1. Create an empty GitHub repository and upload/push this folder as the repository root.
2. Open the repository's **Actions** tab and run **Build CFF** (or push to `main`).
3. Open the completed workflow run.
4. Download the `cff-dev-jars` artifact.
5. The runtime jar is the normal `cff-0.1.0-dev.jar`; do not install the `-sources.jar`.

## On a PC with Gradle
Requirements: Java 21 and Gradle 8.14.x.

Windows:
`gradle build --stacktrace`

macOS/Linux:
`gradle build --stacktrace`

Output: `build/libs/`

## If the build fails
Send the entire Gradle error output. Do not start randomly changing versions; the first compiler error usually tells us which 1.21.11 mapping/API name needs adjustment.
