# CFF — Custom Fluid Framework

Fabric 1.21.11 framework for assigning custom fluids reusable physics profiles and integrating them with Flowing Fluids.

## Current checkpoint
- WATER and LAVA profile model
- custom-fluid/profile registry
- isolated Flowing Fluids API bridge
- Flowing Fluids 1.0.6 compile/runtime dependency
- Java 21 / Minecraft 1.21.11 build configuration
- GitHub Actions build pipeline

The next milestone is compile-verified, placeable WATER-profile and LAVA-profile test fluids. They are intentionally not faked in this checkpoint: their Minecraft 1.21.11 `FlowingFluid` implementation needs to be compiled against the real mapped game classes first.

See `FINISH_BUILD.md` and `TESTING.md`.
