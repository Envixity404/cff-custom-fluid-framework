# CFF v0.1 test plan

Current checkpoint: framework/API bridge. Custom placeable test fluids are the next compile-verified milestone.

## Runtime baseline
- Minecraft Java 1.21.11
- Java 21
- Fabric Loader 0.18.x
- Fabric API for 1.21.11
- Flowing Fluids 1.0.6 (Fabric 1.21.11)
- CFF dev jar

## Smoke test
1. Launch once without CFF and verify Flowing Fluids works.
2. Add CFF jar.
3. Launch and inspect `logs/latest.log` for `CFF v0.1 bootstrap`.
4. If it crashes, save `latest.log` and the newest `crash-reports/*.txt`.

## Fluid test milestone (once test fluids land)
1. Place WATER-profile test fluid in a raised tank and open a one-block outlet.
2. Record drain speed, downhill travel, pooling, and whether fluid duplicates.
3. Repeat with LAVA-profile test fluid.
4. Save/reload the world and verify levels persist.
5. Cross a chunk border and repeat.
6. Record FPS/TPS symptoms and any visual desync.
